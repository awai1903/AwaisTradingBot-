// Example content for subscription_options.dart
