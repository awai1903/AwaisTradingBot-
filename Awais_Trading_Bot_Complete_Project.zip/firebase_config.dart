// Example content for firebase_config.dart
